# Author and funding update QA v1.18

## Funding block
- Funding text: `Project Supported By Smart Grid-National Science and Technology Major Project (2025ZD0806600).`
- A horizontal rule has been added immediately above the funding statement, matching the visual treatment requested from the Word conference template.
- Funding remains on the first page through the IEEEtran `\thanks{}` mechanism.

## Author information
Authors are listed in the requested order:
1. Junxing Tan
2. Jun Wu
3. Shiting Cui
4. Chaofan Yang
5. Jiangcheng Wang

Shared affiliation:
- School of Electrical and Automation Engineering
- Wuhan University
- Wuhan, China

Emails are listed in the same author order:
- 2570734125@qq.com
- byronwu@whu.edu.cn
- 406385846@qq.com
- 552391450@qq.com
- 2383669292@qq.com

The extra closing parenthesis supplied after `Wuhan University)` for Jiangcheng Wang was treated as a typographical error and normalized to `Wuhan University`, consistent with the other authors.

## Compile check
- A4 IEEEtran conference format
- 5 pages
- No undefined references/citations
- No overfull boxes detected
